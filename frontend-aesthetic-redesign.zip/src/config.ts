// ============================================================
// ★ CONFIGURE THESE TWO CONSTANTS ★
// ============================================================
// Your n8n production webhook base URL (no trailing slash)
export const N8N = "https://tapiya2093.app.n8n.cloud/webhook";

// Where student-attendance.html is hosted
export const STUDENT_URL =
  "https://abdelrahman-noaman.github.io/dynamic-qr-attendance/frontend/student-attendance.html";
